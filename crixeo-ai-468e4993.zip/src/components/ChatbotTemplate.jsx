import React from 'react';

export default function ChatbotTemplate({ 
  botId, 
  clientId, 
  botName = "AI Assistant",
  botAvatar,
  color = "#e879f9",
  composerPlaceholder = "Start typing...",
  footer,
  variant = "soft",
  headerVariant = "glass",
  themeMode = "dark",
  fontFamily = "inter",
  radius = 0.5,
  feedbackEnabled = true,
  allowFileUpload = true
}) {

  const iframeSrcDoc = `
    <!doctype html>
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        <style>
          html, body {
            height: 100vh;
            height: 100dvh;
            width: 100% !important;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background: transparent !important;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
          }
          
          @supports (-webkit-touch-callout: none) {
            html, body {
              height: -webkit-fill-available;
            }
          }
        </style>
      </head>
      <body>
        <script src="https://cdn.botpress.cloud/webchat/v3.0/inject.js"></script>
        <script>
          setTimeout(function() {
            window.botpress.init({
              botId: "${botId}",
              clientId: "${clientId}",
              embedded: true,
              configuration: {
                version: "v1",
                composerPlaceholder: "${composerPlaceholder}",
                botName: "${botName}",
                ${botAvatar ? `botAvatar: "${botAvatar}",` : ''}
                color: "${color}",
                variant: "${variant}",
                headerVariant: "${headerVariant}",
                themeMode: "${themeMode}",
                fontFamily: "${fontFamily}",
                radius: ${radius},
                feedbackEnabled: ${feedbackEnabled},
                allowFileUpload: ${allowFileUpload},
                ${footer ? `footer: "${footer}",` : ''}
              }
            });
            setTimeout(function() {
              if (window.botpress && window.botpress.open) {
                window.botpress.open();
              }
            }, 400);
          }, 100);
        </script>
      </body>
    </html>`;

  return (
    <div className="fixed inset-0 bg-black text-white overflow-hidden font-sans">
      {/* Grid Background */}
      <div className="absolute inset-0 bg-grid-white/[0.05] z-0"></div>
      
      {/* Illuminated Background Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vh] bg-pink-500/20 blur-[120px] rounded-full z-0 animate-pulse-slow"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40vw] h-[40vh] bg-blue-500/15 blur-[80px] rounded-full z-0 animate-pulse-slow animation-delay-300"></div>

      {/* Centering container for desktop */}
      <div className="w-full h-full sm:flex sm:items-center sm:justify-center sm:p-4">
        {/* Chat Window Container */}
        <div className="relative w-full h-full bg-black/40 sm:max-w-lg sm:h-[90vh] sm:max-h-[800px] sm:border sm:border-purple-700/60 sm:rounded-2xl shadow-2xl shadow-purple-500/30 sm:backdrop-blur-lg overflow-hidden">
          
          {/* Pulsing Glow Around Chatbot - Only on Desktop */}
          <div className="glow-container absolute inset-0 rounded-none sm:rounded-2xl z-0"></div>
          
          <iframe
            style={{
              width: '100%', 
              height: '100%', 
              border: 'none', 
              background: 'transparent',
              borderRadius: '0px'
            }}
            className="relative z-10 sm:rounded-2xl"
            srcDoc={iframeSrcDoc}
            title={`${botName} Chatbot`}
          ></iframe>
        </div>
      </div>

      <style jsx>{`
        .glow-container {
          animation: chat-glow-pulse-desktop 3s ease-in-out infinite;
        }

        @keyframes chat-glow-pulse-desktop {
          0%, 100% {
            box-shadow:
              0 0 20px ${color},
              0 0 40px ${color},
              0 0 60px ${color},
              0 0 80px ${color};
          }
          50% {
            box-shadow:
              0 0 25px #5eead4,
              0 0 50px #5eead4,
              0 0 75px #5eead4,
              0 0 100px #5eead4;
          }
        }

        @keyframes chat-glow-pulse-mobile {
          0%, 100% {
            box-shadow:
              0 0 5px ${color}cc,
              0 0 10px ${color}99,
              0 0 15px ${color}66;
          }
          50% {
            box-shadow:
              0 0 7px rgba(94, 234, 212, 0.8),
              0 0 15px rgba(94, 234, 212, 0.6),
              0 0 20px rgba(94, 234, 212, 0.4);
          }
        }

        @media (max-width: 639px) {
          .glow-container {
            animation-name: chat-glow-pulse-mobile;
          }
        }
      `}</style>
    </div>
  );
}