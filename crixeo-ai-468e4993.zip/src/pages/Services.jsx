import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BrainCircuit, Bot, LineChart, Code2 } from 'lucide-react';

const services = [
  {
    icon: BrainCircuit,
    title: 'Custom AI Models',
    description: 'We design and train bespoke machine learning models tailored to your specific data and business needs.',
  },
  {
    icon: Bot,
    title: 'Intelligent Chatbots',
    description: 'Engage your customers with smart, conversational AI chatbots that provide support and drive sales 24/7.',
  },
  {
    icon: LineChart,
    title: 'Data Analytics',
    description: 'Unlock valuable insights from your data with our advanced predictive analytics and visualization services.',
  },
  {
    icon: Code2,
    title: 'AI Integration',
    description: 'Seamlessly integrate artificial intelligence into your existing applications and workflows for enhanced efficiency.',
  },
];

export default function ServicesPage() {
  return (
    <div className="py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white">Our Services</h1>
        <p className="mt-4 text-lg text-gray-400">Powering your business with state-of-the-art AI technology.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {services.map((service, index) => (
          <Card key={index} className="bg-gray-900/50 border-gray-800 text-white backdrop-blur-sm transition-all duration-300 hover:border-purple-500/50 hover:shadow-2xl hover:shadow-purple-500/10">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-purple-600/20 rounded-lg">
                  <service.icon className="w-8 h-8 text-purple-400" />
                </div>
                <CardTitle className="text-2xl font-bold">{service.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300">{service.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}