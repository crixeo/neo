import React from 'react';
import ChatbotTemplate from '../components/ChatbotTemplate';

export default function SupportBotPage() {
  return (
    <ChatbotTemplate
      botId="YOUR_SUPPORT_BOT_ID"
      clientId="YOUR_SUPPORT_CLIENT_ID"
      botName="Support Agent"
      color="#3b82f6"
      composerPlaceholder="Describe your issue..."
      footer="[🛠️ Technical Support](https://crixeo.ai)"
    />
  );
}