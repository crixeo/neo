

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Bot, Home, Briefcase, Info, GalleryVertical } from "lucide-react";

const navItems = [
  { name: "Home", href: createPageUrl("Home"), icon: Home },
  { name: "Services", href: createPageUrl("Services"), icon: Briefcase },
  { name: "About", href: createPageUrl("About"), icon: Info },
  { name: "Portfolio", href: createPageUrl("Portfolio"), icon: GalleryVertical },
  { name: "Chat", href: createPageUrl("Chat"), icon: Bot },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  if (currentPageName === "Chat" || currentPageName === "Home" || currentPageName === "Success" || currentPageName === "Cancel") {
    return <>{children}</>;
  }

  return (
    <div className="bg-black text-gray-200 min-h-screen font-sans relative overflow-x-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-grid-white/[0.05] z-0"></div>
      <div className="absolute top-0 left-[-20%] w-[80vw] h-[80vh] bg-purple-600/20 blur-[150px] rounded-full z-0 animate-pulse-slow"></div>
      <div className="absolute bottom-0 right-[-20%] w-[70vw] h-[70vh] bg-blue-600/20 blur-[150px] rounded-full z-0 animate-pulse-slow animation-delay-4000"></div>

      <header className="fixed top-0 left-0 right-0 z-50 bg-black/50 backdrop-blur-lg border-b border-gray-800/50">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to={createPageUrl("Home")} className="text-2xl font-bold tracking-widest text-white hover:text-purple-400 transition-colors">
            CRIXEO
          </Link>
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`relative text-sm font-medium transition-colors ${
                  location.pathname === item.href
                    ? "text-purple-400"
                    : "text-gray-300 hover:text-white"
                }`}
              >
                {item.name}
                {location.pathname === item.href && (
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-purple-400 shadow-[0_0_8px_theme(colors.purple.400)]"></span>
                )}
              </Link>
            ))}
          </div>
          <div className="md:hidden">
            {/* Mobile menu can be added here */}
          </div>
        </nav>
      </header>

      <main className="relative z-10 pt-24 pb-12">
        <div className="container mx-auto px-6">
            {children}
        </div>
      </main>
      
      <footer className="relative z-10 border-t border-gray-800/50 bg-black/30">
        <div className="container mx-auto px-6 py-6 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Crixeo. All rights reserved.</p>
          <p className="mt-2">Innovating the Future, Today.</p>
        </div>
      </footer>
    </div>
  );
}

