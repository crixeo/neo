import React from 'react';
import ChatbotTemplate from '../components/ChatbotTemplate';

export default function SalesBotPage() {
  return (
    <ChatbotTemplate
      botId="YOUR_SALES_BOT_ID"
      clientId="YOUR_SALES_CLIENT_ID"
      botName="Sales Assistant"
      color="#10b981"
      composerPlaceholder="How can I help you today?"
      footer="[💼 Sales Support](https://crixeo.ai)"
    />
  );
}