import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { XCircle, Home, AlertTriangle, Skull } from 'lucide-react';

export default function CancelPage() {
  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-10 right-10 w-32 h-32 bg-red-500/30 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute top-40 left-20 w-48 h-48 bg-pink-500/20 rounded-full blur-3xl animate-pulse-slow animation-delay-300"></div>
        <div className="absolute bottom-20 right-1/3 w-40 h-40 bg-orange-500/25 rounded-full blur-3xl animate-pulse-slow animation-delay-600"></div>
        <div className="absolute top-1/2 left-10 w-24 h-24 bg-red-400/40 rounded-full blur-2xl animate-pulse-slow animation-delay-4000"></div>
      </div>

      {/* Floating Spaceships - Damaged/Retreating */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 right-1/4 animate-retreat-1">
          <div className="w-16 h-8 bg-gradient-to-r from-red-500 to-pink-600 rounded-full shadow-2xl shadow-red-500/50 relative">
            <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-8 h-3 bg-gradient-to-r from-orange-400 to-red-500 rounded-full opacity-50"></div>
            <div className="absolute top-1/2 -left-2 w-6 h-1 bg-red-300 rounded-full opacity-70"></div>
            <div className="absolute top-1/2 -right-2 w-6 h-1 bg-red-300 rounded-full opacity-70"></div>
            {/* Sparks */}
            <div className="absolute top-0 right-0 w-1 h-1 bg-orange-400 rounded-full animate-ping"></div>
          </div>
        </div>
        
        <div className="absolute top-1/3 left-1/4 animate-retreat-2">
          <div className="w-12 h-6 bg-gradient-to-r from-pink-400 to-red-500 rounded-full shadow-2xl shadow-pink-400/50 relative opacity-80">
            <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-6 h-2 bg-gradient-to-r from-red-500 to-pink-600 rounded-full"></div>
            <div className="absolute -top-1 left-0 w-1 h-1 bg-yellow-400 rounded-full animate-ping"></div>
          </div>
        </div>

        <div className="absolute bottom-1/3 right-1/6 animate-retreat-3">
          <div className="w-20 h-10 bg-gradient-to-r from-red-600 to-pink-500 rounded-full shadow-2xl shadow-red-500/50 relative opacity-60">
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-red-300 rounded-full animate-ping"></div>
            <div className="absolute top-0 right-1 w-1 h-1 bg-orange-400 rounded-full animate-ping animation-delay-300"></div>
          </div>
        </div>
      </div>

      {/* Warning Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <AlertTriangle 
            key={i} 
            className={`absolute w-3 h-3 text-red-400 animate-warning-blink`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center min-h-screen px-6">
        <div className="relative p-12 bg-gradient-to-br from-red-900/40 via-pink-900/30 to-orange-900/20 border-2 border-red-500/50 rounded-3xl shadow-2xl shadow-red-500/30 backdrop-blur-2xl">
          {/* Glowing warning orb behind icon */}
          <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-red-500/30 rounded-full blur-2xl animate-pulse-slow"></div>
          
          <div className="relative">
            <XCircle className="relative w-32 h-32 text-red-400 mx-auto animate-warning-shake drop-shadow-2xl" 
                      style={{filter: 'drop-shadow(0 0 20px rgb(248 113 113))'}} />
            <Skull className="absolute top-2 right-2 w-8 h-8 text-pink-400 animate-bounce" />
          </div>
          
          <h1 className="mt-8 text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-pink-400 to-orange-400 animate-gradient-x leading-tight tracking-wider">
            MISSION ABORTED
          </h1>
          
          <div className="mt-6 flex items-center justify-center gap-2">
            <AlertTriangle className="w-6 h-6 text-red-400 animate-bounce" />
            <p className="max-w-md mx-auto text-xl text-red-200 font-light tracking-wide">
              Operation terminated. All systems have been safely powered down.
            </p>
            <AlertTriangle className="w-6 h-6 text-pink-400 animate-bounce animation-delay-300" />
          </div>
          
          <div className="mt-12">
            <Link to={createPageUrl('Home')}>
              <Button 
                size="lg" 
                className="relative bg-gradient-to-r from-red-600 via-pink-600 to-orange-600 hover:from-red-500 hover:via-pink-500 hover:to-orange-500 text-white font-bold text-lg px-8 py-4 rounded-xl shadow-2xl shadow-red-500/50 transition-all duration-300 hover:shadow-red-400/60 hover:scale-105 border border-red-400/50"
                style={{filter: 'drop-shadow(0 0 15px rgb(239 68 68))'}}
              >
                <Home className="mr-3 w-6 h-6" />
                Return to Base
                <div className="absolute inset-0 bg-gradient-to-r from-red-400/20 to-orange-400/20 rounded-xl animate-pulse-slow"></div>
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes retreat-1 {
          0% { transform: translateX(0px) translateY(0px) rotate(0deg); opacity: 1; }
          100% { transform: translateX(200px) translateY(-50px) rotate(45deg); opacity: 0; }
        }
        @keyframes retreat-2 {
          0% { transform: translateX(0px) translateY(0px) rotate(0deg); opacity: 0.8; }
          100% { transform: translateX(-180px) translateY(-30px) rotate(-30deg); opacity: 0; }
        }
        @keyframes retreat-3 {
          0% { transform: translateX(0px) translateY(0px) rotate(0deg); opacity: 0.6; }
          100% { transform: translateX(150px) translateY(40px) rotate(20deg); opacity: 0; }
        }
        @keyframes warning-shake {
          0%, 100% { transform: translateX(0px); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        @keyframes warning-blink {
          0%, 100% { opacity: 0.2; }
          50% { opacity: 1; }
        }
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-retreat-1 { animation: retreat-1 8s linear infinite; }
        .animate-retreat-2 { animation: retreat-2 10s linear infinite; }
        .animate-retreat-3 { animation: retreat-3 9s linear infinite; }
        .animate-warning-shake { animation: warning-shake 0.5s ease-in-out infinite; }
        .animate-warning-blink { animation: warning-blink 1.5s ease-in-out infinite; }
        .animate-gradient-x { 
          background-size: 400% 400%;
          animation: gradient-x 3s ease infinite;
        }
      `}</style>
    </div>
  );
}