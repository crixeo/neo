import React from 'react';
import ChatbotTemplate from '../components/ChatbotTemplate';

export default function ChatPage() {
  return (
    <ChatbotTemplate
      botId="10ff0d92-a4bd-4ff6-9f76-490d391f294a"
      clientId="df3d5528-ea8f-4d4b-8d94-6203fdf00f45"
      botName="NEO"
      botAvatar="https://files.bpcontent.cloud/2025/07/12/04/20250712045926-90TXO9CF.png"
      color="#e879f9"
      composerPlaceholder="Talk to NEO..."
      footer="[⚡ Powered by Crixeo.ai](https://crixeo.ai/?from=webchat)"
    />
  );
}