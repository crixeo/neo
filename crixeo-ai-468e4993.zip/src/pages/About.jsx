import React from 'react';

export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto py-12">
      <div className="text-center">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white">About Crixeo</h1>
        <p className="mt-4 text-lg text-gray-400">Pioneering the AI Frontier</p>
      </div>
      <div className="mt-12 text-left space-y-8 text-gray-300 text-lg leading-relaxed">
        <p>
          At Crixeo, we are driven by a singular mission: to harness the power of artificial intelligence to create a smarter, more efficient world. We believe that AI is not just a technology but a transformative force capable of solving humanity's most complex challenges.
        </p>
        <div className="p-6 border border-purple-500/30 rounded-lg bg-purple-900/10">
          <blockquote className="text-xl italic text-purple-300">
            "Our vision is to democratize access to advanced AI, empowering businesses of all sizes to innovate, grow, and lead in their respective industries."
          </blockquote>
        </div>
        <p>
          Founded by a team of passionate researchers, engineers, and visionaries, Crixeo operates at the intersection of cutting-edge research and practical application. We specialize in developing custom AI solutions, from intelligent automation systems to predictive analytics models, that deliver tangible results and a competitive edge.
        </p>
        <p>
          We are more than just a technology company; we are your partners in innovation. Join us as we build the future, one algorithm at a time.
        </p>
      </div>
    </div>
  );
}