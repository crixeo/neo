import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Bot, Sparkles } from 'lucide-react';

export default function HomePage() {
  return (
    <div className="relative min-h-screen bg-black text-white overflow-hidden font-sans">
      {/* Grid Background */}
      <div className="absolute inset-0 bg-grid-white/[0.05] z-0"></div>
      
      {/* Illuminated Background Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vh] bg-pink-500/20 blur-[150px] rounded-full z-0 animate-pulse-slow"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vh] bg-blue-500/20 blur-[120px] rounded-full z-0 animate-pulse-slow animation-delay-300"></div>

      <div className="relative z-20 flex flex-col items-center justify-center min-h-screen p-4">
        {/* Header/Logo - Visible on Desktop */}
        <header className="hidden md:flex absolute top-10 left-10 items-center gap-4">
          <div className="w-11 h-11 bg-purple-600 rounded-xl flex items-center justify-center">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-pink-500 to-purple-400 bg-clip-text text-transparent">NEO</span>
            <span className="text-base text-gray-400">by Crixeo.ai</span>
          </div>
        </header>

        {/* Content Container - Card on Mobile, Expansive on Desktop */}
        <div className="w-full max-w-sm text-center md:max-w-none md:bg-transparent md:backdrop-blur-none md:border-none md:shadow-none bg-black/70 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-0 shadow-2xl">
          
          {/* Header/Logo - Visible on Mobile (inside card) */}
          <header className="flex md:hidden justify-center items-center gap-2 mb-6">
            <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-400 bg-clip-text text-transparent">NEO</span>
              <span className="text-xs text-gray-400">by Crixeo.ai</span>
            </div>
          </header>

          {/* Illuminated Large NEO Text */}
          <h1 className="text-8xl md:text-[12rem] lg:text-[14rem] font-black text-white leading-none tracking-tighter mb-8 md:mb-10"
              style={{
                textShadow: `
                  0 0 5px #fff,
                  0 0 10px #fff,
                  0 0 20px #e879f9,
                  0 0 35px #e879f9,
                  0 0 40px #e879f9,
                  0 0 50px #e879f9,
                  0 0 75px #e879f9
                `,
                animation: 'illuminate-pulse 3s ease-in-out infinite'
              }}>
            NEO
          </h1>
          
          {/* Description */}
          <div className="max-w-3xl mx-auto mb-10 md:mb-12">
            <p className="text-base md:text-[1.5rem] text-purple-200/90 md:text-white leading-relaxed md:leading-snug">
              <span className="font-bold text-white md:text-purple-300">The Underground System That Changed Everything</span> — a 
              revolutionary platform that combines the explosive power of 
              network marketing with an autonomous AI sales agent. Your 
              psychological warfare specialist that works 24/7 to build your 
              network and generate income for you.
            </p>
          </div>

          {/* CTA Button */}
          <div>
            <Link to={createPageUrl('Chat')}>
              <Button 
                className="w-full md:w-auto bg-gradient-to-r from-purple-600 to-pink-500 hover:opacity-90 text-white font-semibold text-base md:text-lg py-5 md:px-10 md:py-7 rounded-xl md:rounded-2xl transition-all duration-300 shadow-[0_4px_20px_rgba(192,38,211,0.4)]"
              >
                <Bot className="mr-2 md:mr-3 w-5 h-5 md:w-6 md:h-6" />
                Start Conversation
                <Sparkles className="ml-2 md:ml-3 w-5 h-5 md:w-6 md:h-6" />
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes illuminate-pulse {
          0%, 100% {
            text-shadow:
              0 0 5px #fff,
              0 0 10px #fff,
              0 0 20px #e879f9,
              0 0 35px #e879f9,
              0 0 40px #e879f9,
              0 0 50px #e879f9,
              0 0 75px #e879f9;
          }
          50% {
            text-shadow:
              0 0 5px #fff,
              0 0 10px #fff,
              0 0 20px #5eead4,
              0 0 35px #5eead4,
              0 0 40px #5eead4,
              0 0 50px #5eead4,
              0 0 75px #5eead4;
          }
        }
      `}</style>
    </div>
  );
}