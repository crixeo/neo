import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CheckCircle, Home, Zap, Star } from 'lucide-react';

export default function SuccessPage() {
  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-32 h-32 bg-pink-500/30 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute top-40 right-20 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl animate-pulse-slow animation-delay-300"></div>
        <div className="absolute bottom-20 left-1/3 w-40 h-40 bg-cyan-500/25 rounded-full blur-3xl animate-pulse-slow animation-delay-600"></div>
        <div className="absolute top-1/2 right-10 w-24 h-24 bg-pink-400/40 rounded-full blur-2xl animate-pulse-slow animation-delay-4000"></div>
      </div>

      {/* Floating Spaceships */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-1/4 animate-float-1">
          <div className="w-16 h-8 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full shadow-2xl shadow-pink-500/50 relative">
            <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-8 h-3 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"></div>
            <div className="absolute top-1/2 -left-2 w-6 h-1 bg-pink-300 rounded-full"></div>
            <div className="absolute top-1/2 -right-2 w-6 h-1 bg-pink-300 rounded-full"></div>
          </div>
        </div>
        
        <div className="absolute top-1/3 right-1/4 animate-float-2">
          <div className="w-12 h-6 bg-gradient-to-r from-cyan-400 to-pink-500 rounded-full shadow-2xl shadow-cyan-400/50 relative">
            <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-6 h-2 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full"></div>
          </div>
        </div>

        <div className="absolute bottom-1/3 left-1/6 animate-float-3">
          <div className="w-20 h-10 bg-gradient-to-r from-purple-600 to-pink-500 rounded-full shadow-2xl shadow-purple-500/50 relative">
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-pink-300 rounded-full animate-ping"></div>
          </div>
        </div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <Star 
            key={i} 
            className={`absolute w-2 h-2 text-pink-400 animate-twinkle`}
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center min-h-screen px-6">
        <div className="relative p-12 bg-gradient-to-br from-pink-900/40 via-purple-900/30 to-cyan-900/20 border-2 border-pink-500/50 rounded-3xl shadow-2xl shadow-pink-500/30 backdrop-blur-2xl">
          {/* Glowing orb behind icon */}
          <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-pink-500/30 rounded-full blur-2xl animate-pulse-slow"></div>
          
          <CheckCircle className="relative w-32 h-32 text-pink-400 mx-auto animate-float-gentle drop-shadow-2xl" 
                      style={{filter: 'drop-shadow(0 0 20px rgb(244 114 182))'}} />
          
          <h1 className="mt-8 text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 animate-gradient-x leading-tight tracking-wider">
            SUCCESS!
          </h1>
          
          <div className="mt-6 flex items-center justify-center gap-2">
            <Zap className="w-6 h-6 text-pink-400 animate-bounce" />
            <p className="max-w-md mx-auto text-xl text-pink-200 font-light tracking-wide">
              Mission accomplished! Your data has been transmitted to the mothership.
            </p>
            <Zap className="w-6 h-6 text-cyan-400 animate-bounce animation-delay-300" />
          </div>
          
          <div className="mt-12">
            <Link to={createPageUrl('Home')}>
              <Button 
                size="lg" 
                className="relative bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 hover:from-pink-500 hover:via-purple-500 hover:to-cyan-500 text-white font-bold text-lg px-8 py-4 rounded-xl shadow-2xl shadow-pink-500/50 transition-all duration-300 hover:shadow-pink-400/60 hover:scale-105 border border-pink-400/50"
                style={{filter: 'drop-shadow(0 0 15px rgb(236 72 153))'}}
              >
                <Home className="mr-3 w-6 h-6" />
                Return to Base
                <div className="absolute inset-0 bg-gradient-to-r from-pink-400/20 to-cyan-400/20 rounded-xl animate-pulse-slow"></div>
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float-1 {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(5deg); }
        }
        @keyframes float-2 {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(-3deg); }
        }
        @keyframes float-3 {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-25px) rotate(2deg); }
        }
        @keyframes float-gentle {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes gradient-x {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.2); }
        }
        .animate-float-1 { animation: float-1 6s ease-in-out infinite; }
        .animate-float-2 { animation: float-2 8s ease-in-out infinite; }
        .animate-float-3 { animation: float-3 7s ease-in-out infinite; }
        .animate-float-gentle { animation: float-gentle 4s ease-in-out infinite; }
        .animate-gradient-x { 
          background-size: 400% 400%;
          animation: gradient-x 3s ease infinite;
        }
        .animate-twinkle { animation: twinkle 2s ease-in-out infinite; }
      `}</style>
    </div>
  );
}